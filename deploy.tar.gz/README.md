# discord-bot
Discord bot with 24h auto-deploy on Render
